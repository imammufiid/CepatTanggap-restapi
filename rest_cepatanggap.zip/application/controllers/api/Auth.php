<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    var $response;
    public function __construct()
    {
        parent::__construct();
    }


    public function index()
    {
        $api_key = $this->input->get("api_key");
        if (empty($api_key)) {
            echo "Hello World";
        } else {
            echo "yes";
        }
    }

    public function login()
    {
        $username = $this->input->post("username");
        $password = $this->input->post("password");
        $status = 200;
        $message = "";
        $result = [];

        if (empty($username) || empty($password)) {
            $status = 400;
            $message = "Username atau Passoword harus diisi!";
        } else {
            $get_user = $this->db->get_where("users", ["username" => $username])->row();
            if ($get_user) {
                // checking users active
                if ($get_user->status != 1) {
                    $status = 400;
                    $message = "Maaf akun anda tidak aktif";
                }
                // checking password
                else if (password_verify($password, $get_user->password)) {
                    $message = "Berhasil Login...";
                    $result = $get_user;

                    // insert to log
                    $this->myresponses->log($get_user->id, $get_user->api_token, "Melakukan login");
                } else {
                    $status = 400;
                    $message = "Password anda salah!";
                }
            } else {
                $status = 400;
                $message = "Username anda salah!";
            }
        }

        $this->myresponses->json($status, $message, $result);
    }

    public function register()
    {
        $nama_user = $this->input->post("nama_user");
        $username = $this->input->post("email");
        $password = $this->input->post("password");
        $alamat = $this->input->post("alamat");
        $status = 201;
        $message = [];

        if (empty($username) || empty($password) || empty($nama_user)) {
            $status = 400;
            $message = "Form tidak boleh kosong!";
        } else {
            $data = [
                "username" => $username,
                "nama_user" => $nama_user,
                "alamat" => $alamat,
                "api_token" => random_string('md5', 50),
                "status" => 1,
                "password" => password_hash($password, PASSWORD_DEFAULT),
                "created_at" => date("Y-m-d H:i:s")
            ];
            $message = "Anda berhasil daftar!";
            $this->db->insert("users", $data);
            $insert_id = $this->db->insert_id();
            $result = $this->db->get_where('users', ["id", $insert_id])->row();
        }

        $this->myresponses->json($status, $message, $result);
    }
}
